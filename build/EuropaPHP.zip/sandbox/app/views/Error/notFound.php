<h1><?php echo $this->lang->h1; ?></h1>
<h2><?php echo $this->lang->h2(Europa_Request_Http::getRequestUri()); ?></h2>