<h1><?php echo $this->lang->h1; ?></h1>
<h2>~ <?php echo $this->lang->h2; ?> ~</h2>