<?php

/**
 * An example controller sketching some of the features that can be implemented.
 * 
 * @category  Controllers
 * @package   Europa
 * @author    Trey Shugart <treshugart@gmail.com>
 * @copyright (c) 2010 Trey Shugart
 * @link      http://europaphp.org/license
 */
class IndexController extends AbstractController
{
	/**
	 * Processes the main page.
	 * 
	 * @return void
	 */
	public function indexAction()
	{
		
	}
}